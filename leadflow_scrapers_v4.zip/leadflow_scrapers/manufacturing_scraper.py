#!/usr/bin/env python3
"""
Manufacturing Scraper
Factories, machine shops, fabrication

Sources:
- OSHA inspections (fixed version)
- EPA permits
- State manufacturing registrations
"""

import requests
from datetime import datetime, timedelta
from bs4 import BeautifulSoup
import re
import time
import json
from supabase import create_client
import os

SUPABASE_URL = os.getenv('SUPABASE_URL', 'https://fxmclnvdimbnkuzkdnye.supabase.co')
SUPABASE_KEY = os.getenv('SUPABASE_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZ4bWNsbnZkaW1ibmt1emtkbnllIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzAxOTM1NzIsImV4cCI6MjA4NTc2OTU3Mn0.mkhALhXeDzgCzm4GvYCZq6rvYnf25U56HI6521MT_mc')

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
}

# Manufacturing SIC codes
MANUFACTURING_SIC = ['20', '21', '22', '23', '24', '25', '26', '27', '28', '29',
                     '30', '31', '32', '33', '34', '35', '36', '37', '38', '39']


def scrape_osha_api(state):
    """Use OSHA's enforcement data API"""
    leads = []
    
    # OSHA has a public data API
    # https://enforcedata.dol.gov/homePage.php
    
    url = f"https://enforcedata.dol.gov/api/osha/inspection"
    
    params = {
        'state': state,
        'limit': 100,
    }
    
    try:
        response = requests.get(url, params=params, headers=HEADERS, timeout=30)
        
        if response.status_code == 200:
            data = response.json()
            
            for inspection in data.get('results', []):
                company_name = inspection.get('establishment_name', '')
                
                if not company_name:
                    continue
                
                # Check if manufacturing based on SIC
                sic = str(inspection.get('sic_code', ''))[:2]
                if sic not in MANUFACTURING_SIC:
                    continue
                
                lead = {
                    'company_name': company_name.upper()[:200],
                    'industry': 'Manufacturing',
                    'city': inspection.get('city', ''),
                    'state': state,
                    'zip': inspection.get('zip_code', ''),
                    'phone': '',
                    'email': '',
                    'signal_type': 'osha_inspection',
                    'signal_date': datetime.now().strftime('%Y-%m-%d'),
                    'source': 'osha_api',
                    'source_id': f"OSHA-{inspection.get('activity_nr', hash(company_name) % 10000000)}",
                    'employees_estimated': '25-50',
                    'priority': 'HIGH',
                    'score': 85,
                    'lead_type': 'coverage_gap',
                    'stage': 'new',
                    'owner': 'Unassigned',
                }
                
                leads.append(lead)
        
        print(f"[OSHA API] Found {len(leads)} manufacturers in {state}")
        
    except Exception as e:
        print(f"[OSHA API] Error for {state}: {e}")
    
    return leads


def scrape_epa_permits(state):
    """Scrape EPA permits - manufacturers need environmental permits"""
    leads = []
    
    # EPA ECHO database
    url = "https://echo.epa.gov/facilities/facility-search"
    
    # Would need to query the EPA ECHO API
    
    return leads


def run_manufacturing_scraper(states=None):
    """Run manufacturing scraper"""
    if states is None:
        states = ['TX', 'AR', 'GA', 'TN', 'OK', 'LA']
    
    print("=" * 60)
    print(f"Manufacturing Scraper - {datetime.now()}")
    print("=" * 60)
    
    all_leads = []
    
    for state in states:
        print(f"[{state}] Scraping OSHA data...")
        leads = scrape_osha_api(state)
        all_leads.extend(leads)
        time.sleep(2)
    
    print(f"Total: {len(all_leads)} leads")
    return all_leads


if __name__ == '__main__':
    run_manufacturing_scraper()
