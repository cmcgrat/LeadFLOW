#!/usr/bin/env python3
"""
Texas Railroad Commission Scraper
Oil & Gas upstream and services companies

The RRC regulates oil/gas in Texas and publishes:
- New well permits
- Operator registrations
- Pipeline permits
- Service company registrations
"""

import requests
from datetime import datetime, timedelta
from bs4 import BeautifulSoup
import re
import time
from supabase import create_client
import os

SUPABASE_URL = os.getenv('SUPABASE_URL', 'https://fxmclnvdimbnkuzkdnye.supabase.co')
SUPABASE_KEY = os.getenv('SUPABASE_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZ4bWNsbnZkaW1ibmt1emtkbnllIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzAxOTM1NzIsImV4cCI6MjA4NTc2OTU3Mn0.mkhALhXeDzgCzm4GvYCZq6rvYnf25U56HI6521MT_mc')

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
}


def scrape_rrc_new_operators():
    """Scrape new operator registrations from Texas RRC"""
    leads = []
    
    # RRC operator search
    url = "https://webapps.rrc.texas.gov/operator/searchOperator.do"
    
    try:
        response = requests.get(url, headers=HEADERS, timeout=30)
        
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Find operator listings
            rows = soup.find_all('tr')
            
            for row in rows[:100]:
                try:
                    cells = row.find_all('td')
                    if len(cells) < 3:
                        continue
                    
                    company_name = cells[0].get_text(strip=True)
                    
                    if not company_name or len(company_name) < 3:
                        continue
                    
                    # Extract operator number if available
                    operator_num = cells[1].get_text(strip=True) if len(cells) > 1 else ''
                    
                    lead = {
                        'company_name': company_name.upper()[:200],
                        'industry': 'Oil & Gas',
                        'city': '',
                        'state': 'TX',
                        'zip': '',
                        'phone': '',
                        'email': '',
                        'signal_type': 'new_operator',
                        'signal_date': datetime.now().strftime('%Y-%m-%d'),
                        'source': 'texas_rrc',
                        'source_id': f"RRC-{operator_num}" if operator_num else f"RRC-{hash(company_name) % 10000000}",
                        'employees_estimated': '10-25',
                        'priority': 'HIGH',
                        'score': 90,
                        'lead_type': 'likely_uninsured',
                        'stage': 'new',
                        'owner': 'Unassigned',
                    }
                    
                    leads.append(lead)
                    
                except Exception as e:
                    continue
        
        print(f"[RRC] Found {len(leads)} operators")
        
    except Exception as e:
        print(f"[RRC] Error: {e}")
    
    return leads


def scrape_rrc_well_permits():
    """Scrape new well permit applications"""
    leads = []
    
    # Well permit search - companies filing for new drilling permits
    url = "https://webapps.rrc.texas.gov/WPA/searchWellPermit.do"
    
    try:
        response = requests.get(url, headers=HEADERS, timeout=30)
        
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Parse permit data
            # This would need form submission for actual search
            pass
            
    except Exception as e:
        print(f"[RRC Permits] Error: {e}")
    
    return leads


def run_oil_gas_scraper(states=None):
    """Run oil & gas scraper"""
    if states is None:
        states = ['TX', 'OK', 'LA']
    
    print("=" * 60)
    print(f"Oil & Gas Scraper - {datetime.now()}")
    print("=" * 60)
    
    all_leads = []
    
    # Texas RRC
    if 'TX' in states:
        leads = scrape_rrc_new_operators()
        all_leads.extend(leads)
    
    # Add OK and LA scrapers here
    
    print(f"Total: {len(all_leads)} leads")
    return all_leads


if __name__ == '__main__':
    run_oil_gas_scraper()
